﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace prelap6
{
    public partial class Form2 : Form
    {
        // Ayarları tutmak için değişkenler
        private string selectedCategory;
        private int countdownTime;
        private string selectedDifficulty;
        private string selectedImageSet;

        // Kategorilere göre kelime ve ipucu listesi
        private Dictionary<string, List<(string kelime, string ipucu)>> kategoriler = new Dictionary<string, List<(string, string)>>()
        {
            { "Tarih", new List<(string, string)>
                {
                    ("29Ekim", "Cumhuriyet Bayramı"),
                    ("10Kasım", "Atatürk’ün vefat ettiği tarih"),
                    ("19mayıs", "Atatürk’ün Samsun’a çıktığı tarih"),
                    ("OrhanPamuk", "Benim Adım Kırmızı’nın Yazarı"),
                    ( "Roma" , " gladyatörlerin hüküm sürdüğü antik imparatorluk")
                }
            },
            { "Coğrafya", new List<(string, string)>
                {
                    ("gezegen", "uzaydaki büyük cisim"),
                    ("kıta", "birkaç ülkeyi kapsayan büyük kara parçası"),
                    ("köy", "küçük yerleşim yeri"),
                    ("bulut", "gökyüzünde süzülen su damlacıkları"),
                    ("kıtalaşma", "kara parçalarının zamanla ayrılıp bugünkü kıtaları oluşturması olayı")
                }
            },
            { "Matematik", new List<(string, string)>
                {
                    ("açı", "Geometrik bir kavram"),
                    ("çember", "Dairenin sınırı"),
                    ("pi", "Matematikte sabit bir sayı"),
                    ("kare", "Dört eşit kenarlı şekil"),
                    ("parabolik","simetrik eğri çizdiren ikinci dereceden denklem")
                }
            },
            { "Genel Kültür", new List<(string, string)>
                {
                    ("kamera", "fotoğraf ya da video çeker"),
                    ("piyano", "tuşlu müzik aleti"),
                    ("tablet", "taşınabilir elektronik cihaz"),
                    ("lego", "parçalarla kurulan oyuncak"),
                    ("jeopolitik","coğrafyanın siyaset üstündeki etkisi")
                }
            },
            { "Karma", new List<(string, string)>
                {
                    ("kamera", "fotoğraf ya da video çeker"),
                    ("gezegen", "uzaydaki büyük cisim"),
                    ("29Ekim", "Cumhuriyet Bayramı"),
                    ("piyano", "tuşlu müzik aleti"),
                    ("ses", "kulakla duyulur, titreşimle yayılır"),
                    ("biyokimya","canlıların kimyasal yapısını inceleyen bilim dalı")
                }
            }
        };

        string selectedWord;
        string displayWord = "";
        int wrongCount = 0;
        int score = 100;
        List<char> wrongLetters = new List<char>();
        int hintLetterCount = 0; // Maksimum 2 harf ipucu için sayaç
        List<char> hintLetters = new List<char>(); // İpucu alınan harfler

        public Form2(string category, int timeLimit, string difficulty, string imageSet)
        {
            InitializeComponent();

            // Ayarları değişkenlere aktar
            selectedCategory = category;
            countdownTime = timeLimit;
            selectedDifficulty = difficulty;
            selectedImageSet = imageSet;

            timer1.Interval = 1000;
            timer1.Start();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            List<(string kelime, string ipucu)> filteredWords = new List<(string, string)>();

            // Kategoriye göre kelime listesini filtrele
            if (kategoriler.ContainsKey(selectedCategory))
            {
                filteredWords = kategoriler[selectedCategory];
            }

            // Zorluk seviyesine göre kelime listesini filtrele
            switch (selectedDifficulty)
            {
                case "Kolay":
                    filteredWords = filteredWords.Where(word => word.kelime.Length <= 5).ToList();
                    break;

                case "Orta":
                    filteredWords = filteredWords.Where(word => word.kelime.Length > 5 && word.kelime.Length <= 8).ToList();
                    break;

                case "Zor":
                    filteredWords = filteredWords.Where(word => word.kelime.Length > 8).ToList();
                    break;
            }

            // Yeni bir kelime seç
            Random rand = new Random();
            int index = rand.Next(filteredWords.Count);
            selectedWord = filteredWords[index].kelime;
            lblHint.Text = "İpucu: " + filteredWords[index].ipucu;

            lblWordLength.Text = "Kelime uzunluğu: " + selectedWord.Length.ToString();

            displayWord = "";
            for (int i = 0; i < selectedWord.Length; i++)
                displayWord += "_ ";

            lblWordDisplay.Text = displayWord;
            lblScore.Text = "Puan: " + score;
            lblTime.Text = $"Süre: {countdownTime}";
            lblCategory.Text = $"Kategori: {selectedCategory}";
            lblDifficulty.Text = $"Zorluk: {selectedDifficulty}";

            // Resim setine göre başlangıç resmini ayarla
            SetInitialImage();
        }

        private void SetInitialImage()
        {
            switch (selectedImageSet)
            {
                case "Adam As":
                    pictureBox1.Image = Properties.Resources.man_01;
                    break;
                case "Çöp Adam As":
                    pictureBox1.Image = Properties.Resources.stickman_01;
                    break;
                case "Çiçek Yapraklarını Kopar":
                    pictureBox1.Image = Properties.Resources.flower_01;
                    break;
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            if (txtGuess.Text.Length != 1) return;

            char guess = Char.ToLower(txtGuess.Text[0]);
            txtGuess.Clear();

            if (selectedWord.Contains(guess.ToString()))
            {
                char[] tempDisplay = lblWordDisplay.Text.Replace(" ", "").ToCharArray();
                for (int i = 0; i < selectedWord.Length; i++)
                {
                    if (selectedWord[i] == guess)
                    {
                        tempDisplay[i] = guess;
                    }
                }
                lblWordDisplay.Text = string.Join(" ", tempDisplay);

                if (!lblWordDisplay.Text.Contains("_"))
                {
                    MessageBox.Show($"Tebrikler Kazandınız!\nPuanınız: {score}", "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.BackColor = Color.Green;

                    // Ana ekrana dön
                    ReturnToMainMenu();
                }
            }
            else
            {
                if (!wrongLetters.Contains(guess))
                {
                    wrongLetters.Add(guess);
                    lblWrongLetters.Text = "Yanlış Tahmin: " + string.Join(", ", wrongLetters);
                    wrongCount++;
                    score -= 10;
                    lblScore.Text = "Puan: " + score;

                    // Resmi güncelle
                    UpdateImage();
                }
            }
        }

        private void btnHintLetter_Click(object sender, EventArgs e)
        {
            if (hintLetterCount >= 2)
            {
                MessageBox.Show("Maksimum 2 harf ipucu alabilirsiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            for (int i = 0; i < selectedWord.Length; i++)
            {
                if (lblWordDisplay.Text.Replace(" ", "")[i] == '_')
                {
                    char hintLetter = selectedWord[i];
                    if (!hintLetters.Contains(hintLetter))
                    {
                        hintLetters.Add(hintLetter);
                        lblHintLetters.Text = "İpucu Harfler: " + string.Join(", ", hintLetters);
                        char[] tempDisplay = lblWordDisplay.Text.Replace(" ", "").ToCharArray();
                        tempDisplay[i] = hintLetter;
                        lblWordDisplay.Text = string.Join(" ", tempDisplay);
                        hintLetterCount++;
                        score -= 10;
                        lblScore.Text = "Puan: " + score;

                        // Kelimenin tamamlanıp tamamlanmadığını kontrol et
                        CheckWinCondition();
                        break;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblHint.Visible = true; // İpucunu görünür yap
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (countdownTime > 0)
            {
                countdownTime--;
                lblTime.Text = $"Süre: {countdownTime}";
            }
            else
            {
                timer1.Stop();
                MessageBox.Show("SÜRE DOLDU! Doğru kelime: " + selectedWord);
                this.BackColor = Color.Red;

                // Ana ekrana dön
                ReturnToMainMenu();
            }
        }

        private void UpdateImage()
        {
            switch (selectedImageSet)
            {
                case "Adam As":
                    switch (wrongCount)
                    {
                        case 1:
                            pictureBox1.Image = Properties.Resources.man_02;
                            break;
                        case 2:
                            pictureBox1.Image = Properties.Resources.man_03;
                            break;
                        case 3:
                            pictureBox1.Image = Properties.Resources.man_04;
                            break;
                        case 4:
                            pictureBox1.Image = Properties.Resources.man_05;
                            break;
                        case 5:
                            pictureBox1.Image = Properties.Resources.man_06;
                            break;
                        case 6:
                            pictureBox1.Image = Properties.Resources.man_07;
                            break;
                        case 7:
                            pictureBox1.Image = Properties.Resources.man_08;
                            break;
                        case 8:
                            pictureBox1.Image = Properties.Resources.man_09;
                            break;
                    }
                    break;

                case "Çöp Adam As":
                    switch (wrongCount)
                    {
                        case 1:
                            pictureBox1.Image = Properties.Resources.stickman_02;
                            break;
                        case 2:
                            pictureBox1.Image = Properties.Resources.stickman_03;
                            break;
                        case 3:
                            pictureBox1.Image = Properties.Resources.stickman_04;
                            break;
                        case 4:
                            pictureBox1.Image = Properties.Resources.stickman_05;
                            break;
                        case 5:
                            pictureBox1.Image = Properties.Resources.stickman_06;
                            break;
                        case 6:
                            pictureBox1.Image = Properties.Resources.stickman_07;
                            break;
                        case 7:
                            pictureBox1.Image = Properties.Resources.stickman_08;
                            break;
                        case 8:
                            pictureBox1.Image = Properties.Resources.stickman_09;
                            break;
                    }
                    break;

                case "Çiçek Yapraklarını Kopar":
                    switch (wrongCount)
                    {
                        case 1:
                            pictureBox1.Image = Properties.Resources.flower_02;
                            break;
                        case 2:
                            pictureBox1.Image = Properties.Resources.flower_03;
                            break;
                        case 3:
                            pictureBox1.Image = Properties.Resources.flower_04;
                            break;
                        case 4:
                            pictureBox1.Image = Properties.Resources.flower_05;
                            break;
                        case 5:
                            pictureBox1.Image = Properties.Resources.flower_06;
                            break;
                        case 6:
                            pictureBox1.Image = Properties.Resources.flower_07;
                            break;
                        case 7:
                            pictureBox1.Image = Properties.Resources.flower_08;
                            break;
                        case 8:
                            pictureBox1.Image = Properties.Resources.flower_09;
                            break;
                    }
                    break;

                default:
                    MessageBox.Show("Geçersiz resim seti seçildi!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }

            // Eğer maksimum hata sayısına ulaşıldıysa
            if (wrongCount >= 8)
            {
                MessageBox.Show("Kaybettiniz! Doğru kelime: " + selectedWord);
                this.BackColor = Color.Red;

                // Ana ekrana dön
                ReturnToMainMenu();
            }
        }

        private void CheckWinCondition()
        {
            if (!lblWordDisplay.Text.Contains("_")) // Eğer kelimenin tamamı tahmin edildiyse
            {
                MessageBox.Show($"Tebrikler Kazandınız!\nPuanınız: {score}", "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.BackColor = Color.Green;

                // Ana ekrana dön
                ReturnToMainMenu();
            }
        }

        private void ReturnToMainMenu()
        {
            this.Hide(); // Form2'yi gizle
            Form1 mainMenu = new Form1(); // Yeni bir Form1 örneği oluştur
            mainMenu.Show(); // Form1'i göster
            this.Close(); // Form2'yi kapat
        }

        private void btn03_Click(object sender, EventArgs e)
        {
            // Form2'yi kapat ve Form1'e dön
            this.Hide(); // Form2'yi gizle
            Form1 mainMenu = new Form1(); // Yeni bir Form1 örneği oluştur
            mainMenu.Show(); // Form1'i göster
            this.Close(); // Form2'yi kapat
        }
    }
}