﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prelap6
{
    public partial class Form1 : Form
    {
        // Ayarlar için seçilen değerleri tutmak için değişkenler
        private string selectedCategory = "Karma";
        private int selectedTime = 180; // Varsayılan süre
        private string selectedDifficulty = "Kolay"; // Varsayılan zorluk seviyesi
        private string selectedImageSet = "Adam As"; // Varsayılan resim seti

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(selectedCategory, selectedTime, selectedDifficulty, selectedImageSet); // Form2'ye ayarları aktar
            form2.Show(); // Form2'yi göster
            this.Hide(); // Form1'i gizle
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            this.Hide(); // Form1 gizleniyor

            FormUsers userForm = new FormUsers(this);
            if (userForm.ShowDialog() == DialogResult.OK)
            {
                selectedUser = userForm.SelectedUser; // Seçilen kullanıcıyı al
                label1.Text = $"Seçilen Kullanıcı: {selectedUser}"; // Label'a yazdır
            }

            this.Show(); // Form1 tekrar görünür
        }



        private void btnSettings_Click(object sender, EventArgs e)
        {
            // Ayarlar formunu aç
            FormSettings settingsForm = new FormSettings(selectedTime, selectedDifficulty, selectedImageSet);
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                // Ayarlar formundan dönen değerleri al
                selectedTime = settingsForm.SelectedTime;
                selectedDifficulty = settingsForm.SelectedDifficulty;
                selectedImageSet = settingsForm.SelectedImageSet;
            }
        }

        private string selectedUser; // Seçilen kullanıcıyı tutmak için bir değişken

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            // Kullanıcı seçimi kontrolü
            if (string.IsNullOrEmpty(selectedUser))
            {
                MessageBox.Show("Lütfen bir kullanıcı seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kategori seçimini kontrol et
            if (comboBoxCategory.SelectedItem != null)
            {
                selectedCategory = comboBoxCategory.SelectedItem.ToString();
            }
            else
            {
                MessageBox.Show("Lütfen bir kategori seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Oyunu başlat
            Form2 gameForm = new Form2(selectedCategory, selectedTime, selectedDifficulty, selectedImageSet);
            gameForm.Show();
            this.Hide();
        }


        public void UpdateGreeting(string userName)
        {
            lblGreeting.Text = $"MERHABA, {userName}";
        }

    }
}