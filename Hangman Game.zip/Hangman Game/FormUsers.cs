﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace prelap6
{
    public partial class FormUsers : Form
    {
        private List<string> users = new List<string>();
        private const string UsersFilePath = "users.csv";

        public string SelectedUser { get; private set; }

        private Form1 mainForm;

        public FormUsers(Form1 form1)
        {
            InitializeComponent();
            mainForm = form1;
            LoadUsers();
        }

        private void LoadUsers()
        {
            users.Clear();
            if (File.Exists(UsersFilePath))
            {
                var lines = File.ReadAllLines(UsersFilePath);
                users.AddRange(lines);
            }

            lstUsers.Items.Clear();
            foreach (var user in users)
            {
                lstUsers.Items.Add(user);
            }
        }

        private void SaveUsers()
        {
            File.WriteAllLines(UsersFilePath, users);
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            string newUser = ShowInputDialog("Yeni kullanıcı adını girin:");
            if (!string.IsNullOrWhiteSpace(newUser) && !users.Contains(newUser))
            {
                users.Add(newUser);
                lstUsers.Items.Add(newUser);
                SaveUsers();
            }
            else
            {
                MessageBox.Show("Geçersiz veya zaten mevcut bir kullanıcı adı girdiniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSelectUser_Click(object sender, EventArgs e)
        {
            if (lstUsers.SelectedItem != null)
            {
                SelectedUser = lstUsers.SelectedItem.ToString();
                mainForm.UpdateGreeting(SelectedUser);
                this.DialogResult = DialogResult.OK; // önemli
                this.Close();
            }
            else
            {
                MessageBox.Show("Lütfen bir kullanıcı seçin. Kullanıcı seçmeden oyuna devam edemezsiniz.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private string ShowInputDialog(string prompt)
        {
            Form inputForm = new Form();
            inputForm.Width = 300;
            inputForm.Height = 150;
            inputForm.Text = "Kullanıcı Ekle";

            Label lblPrompt = new Label() { Left = 10, Top = 10, Text = prompt };
            TextBox txtInput = new TextBox() { Left = 10, Top = 40, Width = 260 };
            Button btnOk = new Button() { Text = "Tamam", Left = 100, Width = 80, Top = 70, DialogResult = DialogResult.OK };

            inputForm.Controls.Add(lblPrompt);
            inputForm.Controls.Add(txtInput);
            inputForm.Controls.Add(btnOk);
            inputForm.AcceptButton = btnOk;

            if (inputForm.ShowDialog() == DialogResult.OK)
            {
                return txtInput.Text;
            }
            return null;
        }

        private void lstUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            // sadece ön izleme göster, setleme yok
            if (lstUsers.SelectedItem != null)
            {
                string previewUser = lstUsers.SelectedItem.ToString();
                MessageBox.Show($"Seçilen kullanıcı: {previewUser}", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void FormUsers_Load(object sender, EventArgs e)
        {
            btnAddUser.Text = "Kaydet";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lstUsers.SelectedItem != null)
            {
                string userToDelete = lstUsers.SelectedItem.ToString();

                // ListBox'tan kullanıcıyı kaldır
                lstUsers.Items.Remove(userToDelete);

                // users listesinden kullanıcıyı kaldır
                users.Remove(userToDelete);

                // CSV dosyasını güncelle
                SaveUsers();

                MessageBox.Show($"{userToDelete} başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir kullanıcı seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
