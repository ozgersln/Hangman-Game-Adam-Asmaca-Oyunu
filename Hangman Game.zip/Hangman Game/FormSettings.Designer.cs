﻿namespace prelap6
{
    partial class FormSettings
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDownTime = new System.Windows.Forms.NumericUpDown();
            this.comboBoxDifficulty = new System.Windows.Forms.ComboBox();
            this.comboBoxImageSet = new System.Windows.Forms.ComboBox();
            this.btnSaveSettings = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.labelTime = new System.Windows.Forms.Label();
            this.labelDifficulty = new System.Windows.Forms.Label();
            this.labelImageSet = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTime)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDownTime
            // 
            this.numericUpDownTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericUpDownTime.Location = new System.Drawing.Point(158, 23);
            this.numericUpDownTime.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numericUpDownTime.Minimum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numericUpDownTime.Name = "numericUpDownTime";
            this.numericUpDownTime.Size = new System.Drawing.Size(75, 38);
            this.numericUpDownTime.TabIndex = 0;
            this.numericUpDownTime.Value = new decimal(new int[] {
            180,
            0,
            0,
            0});
            // 
            // comboBoxDifficulty
            // 
            this.comboBoxDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxDifficulty.FormattingEnabled = true;
            this.comboBoxDifficulty.Items.AddRange(new object[] {
            "Kolay",
            "Orta",
            "Zor"});
            this.comboBoxDifficulty.Location = new System.Drawing.Point(157, 77);
            this.comboBoxDifficulty.Name = "comboBoxDifficulty";
            this.comboBoxDifficulty.Size = new System.Drawing.Size(227, 39);
            this.comboBoxDifficulty.TabIndex = 1;
            // 
            // comboBoxImageSet
            // 
            this.comboBoxImageSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBoxImageSet.FormattingEnabled = true;
            this.comboBoxImageSet.Items.AddRange(new object[] {
            "Adam As",
            "Çöp Adam As",
            "Çiçek Yapraklarını Kopar"});
            this.comboBoxImageSet.Location = new System.Drawing.Point(215, 130);
            this.comboBoxImageSet.Name = "comboBoxImageSet";
            this.comboBoxImageSet.Size = new System.Drawing.Size(227, 39);
            this.comboBoxImageSet.TabIndex = 2;
            // 
            // btnSaveSettings
            // 
            this.btnSaveSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSaveSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSaveSettings.Location = new System.Drawing.Point(77, 200);
            this.btnSaveSettings.Name = "btnSaveSettings";
            this.btnSaveSettings.Size = new System.Drawing.Size(156, 46);
            this.btnSaveSettings.TabIndex = 3;
            this.btnSaveSettings.Text = "Kaydet";
            this.btnSaveSettings.UseVisualStyleBackColor = false;
            this.btnSaveSettings.Click += new System.EventHandler(this.btnSaveSettings_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCancel.Location = new System.Drawing.Point(271, 200);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(156, 46);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "İptal";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelTime.Location = new System.Drawing.Point(50, 23);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(82, 32);
            this.labelTime.TabIndex = 5;
            this.labelTime.Text = "Süre:";
            // 
            // labelDifficulty
            // 
            this.labelDifficulty.AutoSize = true;
            this.labelDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelDifficulty.Location = new System.Drawing.Point(50, 80);
            this.labelDifficulty.Name = "labelDifficulty";
            this.labelDifficulty.Size = new System.Drawing.Size(101, 32);
            this.labelDifficulty.TabIndex = 6;
            this.labelDifficulty.Text = "Zorluk:";
            // 
            // labelImageSet
            // 
            this.labelImageSet.AutoSize = true;
            this.labelImageSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelImageSet.Location = new System.Drawing.Point(50, 130);
            this.labelImageSet.Name = "labelImageSet";
            this.labelImageSet.Size = new System.Drawing.Size(159, 32);
            this.labelImageSet.TabIndex = 7;
            this.labelImageSet.Text = "Resim Seti:";
            // 
            // FormSettings
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(612, 382);
            this.Controls.Add(this.labelImageSet);
            this.Controls.Add(this.labelDifficulty);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSaveSettings);
            this.Controls.Add(this.comboBoxImageSet);
            this.Controls.Add(this.comboBoxDifficulty);
            this.Controls.Add(this.numericUpDownTime);
            this.Name = "FormSettings";
            this.Text = "Ayarlar";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTime)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDownTime;
        private System.Windows.Forms.ComboBox comboBoxDifficulty;
        private System.Windows.Forms.ComboBox comboBoxImageSet;
        private System.Windows.Forms.Button btnSaveSettings;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labelDifficulty;
        private System.Windows.Forms.Label labelImageSet;
    }
}