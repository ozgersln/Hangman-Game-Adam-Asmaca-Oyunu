﻿namespace prelap6
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblHint = new System.Windows.Forms.Label();
            this.lblWordLength = new System.Windows.Forms.Label();
            this.lblWordDisplay = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblWrongLetters = new System.Windows.Forms.Label();
            this.txtGuess = new System.Windows.Forms.TextBox();
            this.btnGuess = new System.Windows.Forms.Button();
            this.btn03 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.btnHintLetter = new System.Windows.Forms.Button();
            this.lblHintLetters = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblDifficulty = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblHint.Location = new System.Drawing.Point(8, 67);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(63, 24);
            this.lblHint.TabIndex = 0;
            this.lblHint.Text = "İpucu:";
            this.lblHint.Visible = false;
            // 
            // lblWordLength
            // 
            this.lblWordLength.AutoSize = true;
            this.lblWordLength.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblWordLength.Location = new System.Drawing.Point(4, 117);
            this.lblWordLength.Name = "lblWordLength";
            this.lblWordLength.Size = new System.Drawing.Size(161, 24);
            this.lblWordLength.TabIndex = 1;
            this.lblWordLength.Text = "Kelime Uzunluğu:";
            // 
            // lblWordDisplay
            // 
            this.lblWordDisplay.AutoSize = true;
            this.lblWordDisplay.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold);
            this.lblWordDisplay.Location = new System.Drawing.Point(7, 155);
            this.lblWordDisplay.Name = "lblWordDisplay";
            this.lblWordDisplay.Size = new System.Drawing.Size(126, 27);
            this.lblWordDisplay.TabIndex = 2;
            this.lblWordDisplay.Text = "_ _ _ _ _ _ _ _";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblScore.Location = new System.Drawing.Point(8, 182);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(58, 24);
            this.lblScore.TabIndex = 3;
            this.lblScore.Text = "Puan:";
            // 
            // lblWrongLetters
            // 
            this.lblWrongLetters.AutoSize = true;
            this.lblWrongLetters.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblWrongLetters.Location = new System.Drawing.Point(8, 220);
            this.lblWrongLetters.Name = "lblWrongLetters";
            this.lblWrongLetters.Size = new System.Drawing.Size(157, 24);
            this.lblWrongLetters.TabIndex = 4;
            this.lblWrongLetters.Text = "Yanlış Tahminler:";
            // 
            // txtGuess
            // 
            this.txtGuess.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F);
            this.txtGuess.Location = new System.Drawing.Point(12, 290);
            this.txtGuess.Name = "txtGuess";
            this.txtGuess.Size = new System.Drawing.Size(121, 30);
            this.txtGuess.TabIndex = 5;
            // 
            // btnGuess
            // 
            this.btnGuess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnGuess.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.btnGuess.Location = new System.Drawing.Point(168, 275);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(162, 50);
            this.btnGuess.TabIndex = 6;
            this.btnGuess.Text = "Tahmin Et";
            this.btnGuess.UseVisualStyleBackColor = false;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // btn03
            // 
            this.btn03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn03.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.btn03.Location = new System.Drawing.Point(8, 338);
            this.btn03.Name = "btn03";
            this.btn03.Size = new System.Drawing.Size(256, 41);
            this.btn03.TabIndex = 7;
            this.btn03.Text = "Oyunu Bitir";
            this.btn03.UseVisualStyleBackColor = false;
            this.btn03.Click += new System.EventHandler(this.btn03_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(555, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblTime.Location = new System.Drawing.Point(12, 410);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(78, 24);
            this.lblTime.TabIndex = 9;
            this.lblTime.Text = "Süre: 60";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(8, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 39);
            this.button1.TabIndex = 10;
            this.button1.Text = "İpucu Al";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHintLetter
            // 
            this.btnHintLetter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnHintLetter.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnHintLetter.Location = new System.Drawing.Point(481, 397);
            this.btnHintLetter.Name = "btnHintLetter";
            this.btnHintLetter.Size = new System.Drawing.Size(191, 46);
            this.btnHintLetter.TabIndex = 11;
            this.btnHintLetter.Text = "İpucu Harf Al";
            this.btnHintLetter.UseVisualStyleBackColor = false;
            this.btnHintLetter.Click += new System.EventHandler(this.btnHintLetter_Click);
            // 
            // lblHintLetters
            // 
            this.lblHintLetters.AutoSize = true;
            this.lblHintLetters.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHintLetters.Location = new System.Drawing.Point(499, 458);
            this.lblHintLetters.Name = "lblHintLetters";
            this.lblHintLetters.Size = new System.Drawing.Size(138, 24);
            this.lblHintLetters.TabIndex = 12;
            this.lblHintLetters.Text = "İpucu Harfler : ";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblCategory.Location = new System.Drawing.Point(300, 350);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(88, 24);
            this.lblCategory.TabIndex = 13;
            this.lblCategory.Text = "Kategori:";
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold);
            this.lblDifficulty.Location = new System.Drawing.Point(300, 384);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(70, 24);
            this.lblDifficulty.TabIndex = 14;
            this.lblDifficulty.Text = "Zorluk:";
            // 
            // Form2
            // 
            this.ClientSize = new System.Drawing.Size(978, 532);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblHintLetters);
            this.Controls.Add(this.btnHintLetter);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn03);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.txtGuess);
            this.Controls.Add(this.lblWrongLetters);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblWordDisplay);
            this.Controls.Add(this.lblWordLength);
            this.Controls.Add(this.lblHint);
            this.Name = "Form2";
            this.Text = "Hangman Game";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Label lblWordLength;
        private System.Windows.Forms.Label lblWordDisplay;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblWrongLetters;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Button btn03;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnHintLetter;
        private System.Windows.Forms.Label lblHintLetters;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblDifficulty;
    }
}