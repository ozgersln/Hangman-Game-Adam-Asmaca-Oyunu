﻿using System;
using System.Windows.Forms;

namespace prelap6
{
    public partial class FormSettings : Form
    {
        // Ayarları tutmak için public özellikler
        public int SelectedTime { get; private set; } = 180; // Varsayılan süre
        public string SelectedDifficulty { get; private set; } = "Kolay"; // Varsayılan zorluk seviyesi
        public string SelectedImageSet { get; private set; } = "Adam As"; // Varsayılan resim seti

        public FormSettings(int currentTime, string currentDifficulty, string currentImageSet)
        {
            InitializeComponent();

            // Mevcut ayarları yükle
            numericUpDownTime.Value = currentTime;
            comboBoxDifficulty.SelectedItem = currentDifficulty;
            comboBoxImageSet.SelectedItem = currentImageSet;
        }

        private void btnSaveSettings_Click(object sender, EventArgs e)
        {
            // Kullanıcı seçimlerini al
            SelectedTime = (int)numericUpDownTime.Value;
            SelectedDifficulty = comboBoxDifficulty.SelectedItem?.ToString() ?? "Kolay";
            SelectedImageSet = comboBoxImageSet.SelectedItem?.ToString() ?? "Adam As";

            // Ayarları kaydet ve formu kapat
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Değişiklikleri iptal et ve formu kapat
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}